import React from 'react';

const TabPanel = ({ children }) => {
  return <div>{children}</div>;
};

export default TabPanel;
